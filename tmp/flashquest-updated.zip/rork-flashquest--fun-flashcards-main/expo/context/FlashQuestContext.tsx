import AsyncStorage from '@react-native-async-storage/async-storage';
import createContextHook from '@nkzw/create-context-hook';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useCallback, useMemo, useRef } from 'react';

import { SAMPLE_DECKS } from '@/data/sampleDecks';
import type { Achievement, Deck, Flashcard, FlashcardNormalizationSource, UserProgress, UserStats } from '@/types/flashcard';
import type { GameResultParams } from '@/types/game';
import { logger } from '@/utils/logger';
import { scheduleStreakReminder } from '@/utils/notifications';
import { mergeFlashcardUpdates, normalizeDeck, normalizeDeckCollection } from '@/utils/flashcardContent';

const STORAGE_KEYS = {
  DECKS: 'flashquest_decks',
  PROGRESS: 'flashquest_progress',
  STATS: 'flashquest_stats',
} as const;

const STORAGE_BACKUP_KEYS = {
  DECKS: 'flashquest_decks_backup',
  PROGRESS: 'flashquest_progress_backup',
  STATS: 'flashquest_stats_backup',
} as const;

const DEFAULT_STATS: UserStats = {
  totalScore: 0,
  currentStreak: 0,
  longestStreak: 0,
  totalCardsStudied: 0,
  totalDecksCompleted: 0,
  achievements: [],
  lastActiveDate: new Date().toISOString().split('T')[0],
  totalCorrectAnswers: 0,
  totalQuestionsAttempted: 0,
  studyDates: [],
  totalStudySessions: 0,
  totalQuestSessions: 0,
  totalPracticeSessions: 0,
  totalArenaSessions: 0,
  totalArenaBattles: 0,
  totalStudyTimeMs: 0,
  weeklyAccuracy: [],
};

const SAMPLE_DECKS_BY_ID = new Map<string, Deck>(SAMPLE_DECKS.map((deck) => [deck.id, deck]));
const BUILT_IN_DECK_IDS = new Set<string>(SAMPLE_DECKS.map((deck) => deck.id));

function cloneDefaultStats(): UserStats {
  return {
    ...DEFAULT_STATS,
    achievements: [...DEFAULT_STATS.achievements],
    studyDates: [...DEFAULT_STATS.studyDates],
    weeklyAccuracy: [...DEFAULT_STATS.weeklyAccuracy],
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function parseStoredJson(raw: string): unknown {
  try {
    return JSON.parse(raw) as unknown;
  } catch (error) {
    logger.warn('[FlashQuest] Failed to parse persisted JSON:', error);
    return null;
  }
}

function normalizeAchievement(value: unknown): Achievement | null {
  if (!isRecord(value)) {
    return null;
  }

  if (
    typeof value.id !== 'string'
    || typeof value.name !== 'string'
    || typeof value.description !== 'string'
    || typeof value.icon !== 'string'
    || typeof value.progress !== 'number'
    || typeof value.maxProgress !== 'number'
  ) {
    return null;
  }

  return {
    id: value.id,
    name: value.name,
    description: value.description,
    icon: value.icon,
    unlockedAt: typeof value.unlockedAt === 'number' ? value.unlockedAt : undefined,
    progress: value.progress,
    maxProgress: value.maxProgress,
  };
}

function normalizeWeeklyAccuracyEntry(value: unknown): { week: string; correct: number; attempted: number } | null {
  if (!isRecord(value)) {
    return null;
  }

  if (
    typeof value.week !== 'string'
    || typeof value.correct !== 'number'
    || typeof value.attempted !== 'number'
  ) {
    return null;
  }

  return {
    week: value.week,
    correct: value.correct,
    attempted: value.attempted,
  };
}

function normalizeUserStats(value: unknown): UserStats | null {
  if (!isRecord(value)) {
    return null;
  }

  const defaultStats = cloneDefaultStats();

  return {
    totalScore: typeof value.totalScore === 'number' ? value.totalScore : defaultStats.totalScore,
    currentStreak: typeof value.currentStreak === 'number' ? value.currentStreak : defaultStats.currentStreak,
    longestStreak: typeof value.longestStreak === 'number' ? value.longestStreak : defaultStats.longestStreak,
    totalCardsStudied: typeof value.totalCardsStudied === 'number' ? value.totalCardsStudied : defaultStats.totalCardsStudied,
    totalDecksCompleted: typeof value.totalDecksCompleted === 'number' ? value.totalDecksCompleted : defaultStats.totalDecksCompleted,
    achievements: Array.isArray(value.achievements)
      ? value.achievements
        .map((item) => normalizeAchievement(item))
        .filter((item): item is Achievement => item !== null)
      : defaultStats.achievements,
    lastActiveDate: typeof value.lastActiveDate === 'string' && value.lastActiveDate.length > 0
      ? value.lastActiveDate
      : defaultStats.lastActiveDate,
    totalCorrectAnswers: typeof value.totalCorrectAnswers === 'number' ? value.totalCorrectAnswers : defaultStats.totalCorrectAnswers,
    totalQuestionsAttempted: typeof value.totalQuestionsAttempted === 'number' ? value.totalQuestionsAttempted : defaultStats.totalQuestionsAttempted,
    studyDates: Array.isArray(value.studyDates)
      ? value.studyDates.filter((item): item is string => typeof item === 'string')
      : defaultStats.studyDates,
    totalStudySessions: typeof value.totalStudySessions === 'number' ? value.totalStudySessions : defaultStats.totalStudySessions,
    totalQuestSessions: typeof value.totalQuestSessions === 'number' ? value.totalQuestSessions : defaultStats.totalQuestSessions,
    totalPracticeSessions: typeof value.totalPracticeSessions === 'number' ? value.totalPracticeSessions : defaultStats.totalPracticeSessions,
    totalArenaSessions: typeof value.totalArenaSessions === 'number' ? value.totalArenaSessions : defaultStats.totalArenaSessions,
    totalArenaBattles: typeof value.totalArenaBattles === 'number' ? value.totalArenaBattles : defaultStats.totalArenaBattles,
    totalStudyTimeMs: typeof value.totalStudyTimeMs === 'number' ? value.totalStudyTimeMs : defaultStats.totalStudyTimeMs,
    weeklyAccuracy: Array.isArray(value.weeklyAccuracy)
      ? value.weeklyAccuracy
        .map((item) => normalizeWeeklyAccuracyEntry(item))
        .filter((item): item is { week: string; correct: number; attempted: number } => item !== null)
      : defaultStats.weeklyAccuracy,
  };
}

function normalizeUserProgressEntry(value: unknown): UserProgress | null {
  if (!isRecord(value)) {
    return null;
  }

  if (
    typeof value.deckId !== 'string'
    || typeof value.cardsReviewed !== 'number'
    || typeof value.lastStudied !== 'number'
  ) {
    return null;
  }

  return {
    deckId: value.deckId,
    cardsReviewed: value.cardsReviewed,
    lastStudied: value.lastStudied,
    masteredCards: Array.isArray(value.masteredCards)
      ? value.masteredCards.filter((item): item is string => typeof item === 'string')
      : [],
  };
}

function normalizeStoredProgress(value: unknown): UserProgress[] | null {
  if (!Array.isArray(value)) {
    return null;
  }

  return value
    .map((item) => normalizeUserProgressEntry(item))
    .filter((item): item is UserProgress => item !== null);
}

function normalizeStoredDeckPayload(value: unknown): Deck[] | null {
  if (!Array.isArray(value)) {
    return null;
  }

  return value as Deck[];
}

async function persistMirroredStorage<T>(primaryKey: string, backupKey: string, value: T, label: string): Promise<T> {
  const serialized = JSON.stringify(value);
  await Promise.all([
    AsyncStorage.setItem(primaryKey, serialized),
    AsyncStorage.setItem(backupKey, serialized),
  ]);
  logger.debug('[FlashQuest] Persisted mirrored storage for', label);
  return value;
}

async function readMirroredStorage<T>(options: {
  primaryKey: string;
  backupKey: string;
  label: string;
  fallback: T;
  parse: (value: unknown) => T | null;
}): Promise<T> {
  const { primaryKey, backupKey, label, fallback, parse } = options;

  try {
    const primaryRaw = await AsyncStorage.getItem(primaryKey);

    if (primaryRaw != null) {
      const parsedPrimary = parseStoredJson(primaryRaw);
      const normalizedPrimary = parsedPrimary == null ? null : parse(parsedPrimary);

      if (normalizedPrimary != null) {
        try {
          const backupRaw = await AsyncStorage.getItem(backupKey);
          if (backupRaw !== primaryRaw) {
            await persistMirroredStorage(primaryKey, backupKey, normalizedPrimary, `${label} mirror sync`);
          }
        } catch (error) {
          logger.warn('[FlashQuest] Mirror sync failed during read for', label, error);
        }
        return normalizedPrimary;
      }

      logger.warn('[FlashQuest] Primary persisted payload was invalid, trying backup for', label);
    }

    const backupRaw = await AsyncStorage.getItem(backupKey);
    if (backupRaw != null) {
      const parsedBackup = parseStoredJson(backupRaw);
      const normalizedBackup = parsedBackup == null ? null : parse(parsedBackup);

      if (normalizedBackup != null) {
        logger.debug('[FlashQuest] Recovered', label, 'from backup storage');
        try {
          await persistMirroredStorage(primaryKey, backupKey, normalizedBackup, `${label} recovery`);
        } catch (error) {
          logger.warn('[FlashQuest] Mirror recovery persist failed for', label, error);
        }
        return normalizedBackup;
      }

      logger.warn('[FlashQuest] Backup persisted payload was invalid for', label);
    }
  } catch (error) {
    logger.error('[FlashQuest] Failed to read mirrored storage for', label, error);
  }

  logger.debug('[FlashQuest] Falling back to default payload for', label);
  return fallback;
}

function syncSampleDeck(existingDeck: Deck | undefined, sampleDeck: Deck): Deck {
  const existingCardsById = new Map<string, Flashcard>((existingDeck?.flashcards ?? []).map((card) => [card.id, card]));

  return {
    ...sampleDeck,
    createdAt: existingDeck?.createdAt ?? sampleDeck.createdAt,
    flashcards: sampleDeck.flashcards.map((card) => {
      const existingCard = existingCardsById.get(card.id);
      return {
        ...card,
        createdAt: existingCard?.createdAt ?? card.createdAt,
      };
    }),
  };
}

function reconcileDeckCatalog(
  decks: Deck[],
  source: FlashcardNormalizationSource = 'deck_update',
): { decks: Deck[]; didChange: boolean } {
  const seenSampleDeckIds = new Set<string>();
  let didChange = false;

  const syncedDecks = decks.map((deck) => {
    if (deck.isCustom) {
      return deck;
    }

    const sampleDeck = SAMPLE_DECKS_BY_ID.get(deck.id);
    if (!sampleDeck) {
      return deck;
    }

    seenSampleDeckIds.add(deck.id);
    const syncedDeck = syncSampleDeck(deck, sampleDeck);

    if (JSON.stringify(deck) !== JSON.stringify(syncedDeck)) {
      didChange = true;
    }

    return syncedDeck;
  });

  SAMPLE_DECKS.forEach((sampleDeck) => {
    if (seenSampleDeckIds.has(sampleDeck.id)) {
      return;
    }

    syncedDecks.push(sampleDeck);
    didChange = true;
  });

  const normalizedDecks = normalizeDeckCollection(syncedDecks, {
    source,
    trackDiagnostics: true,
  });

  return {
    decks: normalizedDecks.decks,
    didChange: didChange || normalizedDecks.didChange,
  };
}

function computeStreak(
  lastActiveDate: string,
  currentStreak: number,
  longestStreak: number,
): { currentStreak: number; longestStreak: number } {
  const today = new Date().toISOString().split('T')[0];

  if (lastActiveDate === today) {
    return { currentStreak, longestStreak };
  }

  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  if (lastActiveDate === yesterday) {
    const newStreak = currentStreak + 1;
    return {
      currentStreak: newStreak,
      longestStreak: Math.max(longestStreak, newStreak),
    };
  }

  return {
    currentStreak: 1,
    longestStreak: Math.max(longestStreak, 1),
  };
}

function getIsoWeekString(date: Date): string {
  const normalized = new Date(date);
  normalized.setHours(0, 0, 0, 0);
  normalized.setDate(normalized.getDate() + 3 - ((normalized.getDay() + 6) % 7));
  const week1 = new Date(normalized.getFullYear(), 0, 4);
  const weekNum = 1 + Math.round(
    ((normalized.getTime() - week1.getTime()) / 86400000 - 3 + ((week1.getDay() + 6) % 7)) / 7,
  );

  return `${normalized.getFullYear()}-W${String(weekNum).padStart(2, '0')}`;
}

function normalizeLoadedStats(stats: UserStats): { stats: UserStats; didChange: boolean } {
  const today = new Date().toISOString().split('T')[0];
  const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];

  if (stats.lastActiveDate === today || stats.lastActiveDate === yesterday) {
    return { stats, didChange: false };
  }

  return {
    stats: { ...stats, currentStreak: 0 },
    didChange: true,
  };
}

async function loadDecksSnapshot(): Promise<Deck[]> {
  try {
    const storedDecks = await readMirroredStorage<Deck[]>({
      primaryKey: STORAGE_KEYS.DECKS,
      backupKey: STORAGE_BACKUP_KEYS.DECKS,
      label: 'decks',
      fallback: SAMPLE_DECKS,
      parse: normalizeStoredDeckPayload,
    });
    const normalizedDecks = reconcileDeckCatalog(storedDecks, 'legacy_load_normalization');

    if (normalizedDecks.didChange) {
      logger.debug('[FlashQuest] Synced built-in decks with latest default content');
      try {
        await persistMirroredStorage(STORAGE_KEYS.DECKS, STORAGE_BACKUP_KEYS.DECKS, normalizedDecks.decks, 'decks normalization');
      } catch (error) {
        logger.warn('[FlashQuest] Failed to persist normalized deck catalog during load', error);
      }
    }

    return normalizedDecks.decks;
  } catch (error) {
    logger.error('[FlashQuest] Failed to load deck snapshot, restoring built-in decks only', error);
    return reconcileDeckCatalog(SAMPLE_DECKS, 'legacy_load_normalization').decks;
  }
}

async function loadProgressSnapshot(): Promise<UserProgress[]> {
  return readMirroredStorage<UserProgress[]>({
    primaryKey: STORAGE_KEYS.PROGRESS,
    backupKey: STORAGE_BACKUP_KEYS.PROGRESS,
    label: 'progress',
    fallback: [],
    parse: normalizeStoredProgress,
  });
}

async function loadStatsSnapshot(): Promise<UserStats> {
  const storedStats = await readMirroredStorage<UserStats>({
    primaryKey: STORAGE_KEYS.STATS,
    backupKey: STORAGE_BACKUP_KEYS.STATS,
    label: 'stats',
    fallback: cloneDefaultStats(),
    parse: normalizeUserStats,
  });
  const normalizedStats = normalizeLoadedStats(storedStats);

  if (normalizedStats.didChange) {
    try {
      await persistMirroredStorage(STORAGE_KEYS.STATS, STORAGE_BACKUP_KEYS.STATS, normalizedStats.stats, 'stats streak correction');
    } catch (error) {
      logger.warn('[FlashQuest] Failed to persist corrected stats during load', error);
    }
  }

  return normalizedStats.stats;
}

export const [FlashQuestProvider, useFlashQuest] = createContextHook(() => {
  const queryClient = useQueryClient();
  const persistenceQueueRef = useRef<Promise<void>>(Promise.resolve());

  const decksQuery = useQuery({
    queryKey: ['decks'],
    queryFn: loadDecksSnapshot,
  });

  const progressQuery = useQuery({
    queryKey: ['progress'],
    queryFn: loadProgressSnapshot,
  });

  const statsQuery = useQuery({
    queryKey: ['stats'],
    queryFn: loadStatsSnapshot,
  });

  const saveDecksMutation = useMutation({
    mutationFn: async (decks: Deck[]) => {
      const reconciledDecks = reconcileDeckCatalog(decks, 'deck_update').decks;
      return persistMirroredStorage(STORAGE_KEYS.DECKS, STORAGE_BACKUP_KEYS.DECKS, reconciledDecks, 'decks');
    },
    onSuccess: (decks: Deck[]) => {
      queryClient.setQueryData(['decks'], decks);
    },
  });
  const { mutateAsync: saveDecksMutateAsync } = saveDecksMutation;

  const saveProgressMutation = useMutation({
    mutationFn: async (progress: UserProgress[]) => persistMirroredStorage(STORAGE_KEYS.PROGRESS, STORAGE_BACKUP_KEYS.PROGRESS, progress, 'progress'),
    onSuccess: (progress: UserProgress[]) => {
      queryClient.setQueryData(['progress'], progress);
    },
  });
  const { mutateAsync: saveProgressMutateAsync } = saveProgressMutation;

  const saveStatsMutation = useMutation({
    mutationFn: async (stats: UserStats) => persistMirroredStorage(STORAGE_KEYS.STATS, STORAGE_BACKUP_KEYS.STATS, stats, 'stats'),
    onSuccess: (stats: UserStats) => {
      queryClient.setQueryData(['stats'], stats);
    },
  });
  const { mutateAsync: saveStatsMutateAsync } = saveStatsMutation;

  const enqueuePersistenceTask = useCallback(async function runPersistenceTask<T>(
    label: string,
    task: () => Promise<T>,
  ): Promise<T> {
    let result: T | undefined;

    persistenceQueueRef.current = persistenceQueueRef.current
      .catch((error) => {
        logger.error('[FlashQuest] Previous persistence task failed before', label, error);
      })
      .then(async () => {
        logger.debug('[FlashQuest] Running persistence task:', label);
        result = await task();
      });

    await persistenceQueueRef.current;
    return result as T;
  }, []);

  const getHydratedDecks = useCallback(async (): Promise<Deck[]> => {
    const cachedDecks = queryClient.getQueryData<Deck[]>(['decks']);
    if (cachedDecks != null) {
      const reconciledCachedDecks = reconcileDeckCatalog(cachedDecks, 'deck_update');
      if (reconciledCachedDecks.didChange) {
        queryClient.setQueryData(['decks'], reconciledCachedDecks.decks);
      }
      return reconciledCachedDecks.decks;
    }

    const hydratedDecks = await loadDecksSnapshot();
    queryClient.setQueryData(['decks'], hydratedDecks);
    return hydratedDecks;
  }, [queryClient]);

  const getHydratedProgress = useCallback(async (): Promise<UserProgress[]> => {
    const cachedProgress = queryClient.getQueryData<UserProgress[]>(['progress']);
    if (cachedProgress != null) {
      return cachedProgress;
    }

    const hydratedProgress = await loadProgressSnapshot();
    queryClient.setQueryData(['progress'], hydratedProgress);
    return hydratedProgress;
  }, [queryClient]);

  const getHydratedStats = useCallback(async (): Promise<UserStats> => {
    const cachedStats = queryClient.getQueryData<UserStats>(['stats']);
    if (cachedStats != null) {
      return cachedStats;
    }

    const hydratedStats = await loadStatsSnapshot();
    queryClient.setQueryData(['stats'], hydratedStats);
    return hydratedStats;
  }, [queryClient]);

  const recordSessionResult = useCallback((params: GameResultParams) => {
    void enqueuePersistenceTask('recordSessionResult', async () => {
      const currentStats = await getHydratedStats();
      const today = new Date().toISOString().split('T')[0];

      const { currentStreak: newStreak, longestStreak: newLongest } = computeStreak(
        currentStats.lastActiveDate,
        currentStats.currentStreak,
        currentStats.longestStreak,
      );

      const correctAnswersToAdd = params.correctCount != null ? params.correctCount : 0;
      const questionsAttemptedToAdd = params.correctCount != null ? params.cardsAttempted : 0;
      const existingStudyDates = currentStats.studyDates ?? [];
      const studyDatesUpdated = existingStudyDates.includes(today) ? existingStudyDates : [...existingStudyDates, today].slice(-365);
      const weekNumber = getIsoWeekString(new Date());
      const existingWeekly = currentStats.weeklyAccuracy ?? [];
      const currentWeekEntry = existingWeekly.find((entry) => entry.week === weekNumber);
      const weeklyCorrectToAdd = params.correctCount ?? 0;
      const weeklyAttemptedToAdd = params.correctCount != null ? params.cardsAttempted : 0;
      let updatedWeekly: { week: string; correct: number; attempted: number }[];

      if (currentWeekEntry) {
        updatedWeekly = existingWeekly.map((entry) => (
          entry.week === weekNumber
            ? {
                ...entry,
                correct: entry.correct + weeklyCorrectToAdd,
                attempted: entry.attempted + weeklyAttemptedToAdd,
              }
            : entry
        ));
      } else {
        updatedWeekly = [
          ...existingWeekly,
          {
            week: weekNumber,
            correct: weeklyCorrectToAdd,
            attempted: weeklyAttemptedToAdd,
          },
        ];
      }

      updatedWeekly = updatedWeekly
        .sort((a, b) => a.week.localeCompare(b.week))
        .slice(-12);

      const updatedStats: UserStats = {
        ...currentStats,
        totalScore: currentStats.totalScore + params.xpEarned,
        totalCardsStudied: currentStats.totalCardsStudied + params.cardsAttempted,
        currentStreak: newStreak,
        longestStreak: newLongest,
        lastActiveDate: today,
        totalCorrectAnswers: (currentStats.totalCorrectAnswers ?? 0) + correctAnswersToAdd,
        totalQuestionsAttempted: (currentStats.totalQuestionsAttempted ?? 0) + questionsAttemptedToAdd,
        studyDates: studyDatesUpdated,
        totalStudySessions: (currentStats.totalStudySessions ?? 0) + (params.mode === 'study' ? 1 : 0),
        totalQuestSessions: (currentStats.totalQuestSessions ?? 0) + (params.mode === 'quest' ? 1 : 0),
        totalPracticeSessions: (currentStats.totalPracticeSessions ?? 0) + (params.mode === 'practice' ? 1 : 0),
        totalArenaSessions: (currentStats.totalArenaSessions ?? 0) + (params.mode === 'arena' ? 1 : 0),
        totalArenaBattles: (currentStats.totalArenaBattles ?? 0) + (params.mode === 'arena' ? 1 : 0),
        totalStudyTimeMs: (currentStats.totalStudyTimeMs ?? 0) + (params.durationMs ?? 0),
        weeklyAccuracy: updatedWeekly,
      };

      logger.debug(
        '[FlashQuest] recordSessionResult',
        params.mode,
        'xp:',
        params.xpEarned,
        'cards:',
        params.cardsAttempted,
        'streak:',
        newStreak,
      );

      const previousProgress = params.deckId ? await getHydratedProgress() : null;
      const updatedProgress = params.deckId
        ? (() => {
            const currentProgress = previousProgress ?? [];
            const existingIndex = currentProgress.findIndex((entry) => entry.deckId === params.deckId);

            if (existingIndex >= 0) {
              const existing = currentProgress[existingIndex];
              const nextProgress = [...currentProgress];
              nextProgress[existingIndex] = {
                ...existing,
                cardsReviewed: existing.cardsReviewed + params.cardsAttempted,
                lastStudied: Date.now(),
              };
              return nextProgress;
            }

            return [
              ...currentProgress,
              {
                deckId: params.deckId,
                cardsReviewed: params.cardsAttempted,
                lastStudied: Date.now(),
                masteredCards: [],
              },
            ];
          })()
        : null;

      queryClient.setQueryData(['stats'], updatedStats);
      if (updatedProgress != null) {
        queryClient.setQueryData(['progress'], updatedProgress);
      }

      try {
        await Promise.all([
          saveStatsMutateAsync(updatedStats),
          updatedProgress != null ? saveProgressMutateAsync(updatedProgress) : Promise.resolve([]),
        ]);
      } catch (error) {
        queryClient.setQueryData(['stats'], currentStats);
        if (previousProgress != null) {
          queryClient.setQueryData(['progress'], previousProgress);
        }
        logger.error('[FlashQuest] Failed to persist session result, rolled back cache', error);
        throw error;
      }

      scheduleStreakReminder({ requestPermissionIfNeeded: true }).catch(() => {});
    }).catch((error) => {
      logger.error('[FlashQuest] recordSessionResult task failed', error);
    });
  }, [enqueuePersistenceTask, getHydratedProgress, getHydratedStats, queryClient, saveProgressMutateAsync, saveStatsMutateAsync]);

  const addDeck = useCallback((deck: Deck) => {
    void enqueuePersistenceTask('addDeck', async () => {
      const currentDecks = await getHydratedDecks();
      const normalizedDeck = normalizeDeck(deck);
      const updatedDecks = reconcileDeckCatalog([...currentDecks, normalizedDeck], 'deck_update').decks;
      queryClient.setQueryData(['decks'], updatedDecks);

      try {
        await saveDecksMutateAsync(updatedDecks);
      } catch (error) {
        queryClient.setQueryData(['decks'], currentDecks);
        logger.error('[FlashQuest] Failed to persist added deck, rolled back cache', error);
        throw error;
      }
    }).catch((error) => {
      logger.error('[FlashQuest] addDeck task failed', error);
    });
  }, [enqueuePersistenceTask, getHydratedDecks, queryClient, saveDecksMutateAsync]);

  const updateDeck = useCallback((deckId: string, updates: Partial<Deck>) => {
    void enqueuePersistenceTask('updateDeck', async () => {
      const currentDecks = await getHydratedDecks();
      const updatedDecks = reconcileDeckCatalog(currentDecks.map((deck) => (
        deck.id === deckId ? normalizeDeck({ ...deck, ...updates }) : deck
      )), 'deck_update').decks;
      queryClient.setQueryData(['decks'], updatedDecks);

      try {
        await saveDecksMutateAsync(updatedDecks);
      } catch (error) {
        queryClient.setQueryData(['decks'], currentDecks);
        logger.error('[FlashQuest] Failed to persist updated deck, rolled back cache', error);
        throw error;
      }
    }).catch((error) => {
      logger.error('[FlashQuest] updateDeck task failed', error);
    });
  }, [enqueuePersistenceTask, getHydratedDecks, queryClient, saveDecksMutateAsync]);

  const updateFlashcard = useCallback((deckId: string, cardId: string, updates: Partial<Flashcard>) => {
    void enqueuePersistenceTask('updateFlashcard', async () => {
      const currentDecks = await getHydratedDecks();
      const updatedDecks = reconcileDeckCatalog(currentDecks.map((deck) => {
        if (deck.id !== deckId) {
          return deck;
        }

        return normalizeDeck({
          ...deck,
          flashcards: deck.flashcards.map((card) => (
            card.id === cardId ? mergeFlashcardUpdates(card, updates) : card
          )),
        });
      }), 'deck_update').decks;

      queryClient.setQueryData(['decks'], updatedDecks);

      try {
        await saveDecksMutateAsync(updatedDecks);
      } catch (error) {
        queryClient.setQueryData(['decks'], currentDecks);
        logger.error('[FlashQuest] Failed to persist flashcard update, rolled back cache', error);
        throw error;
      }
    }).catch((error) => {
      logger.error('[FlashQuest] updateFlashcard task failed', error);
    });
  }, [enqueuePersistenceTask, getHydratedDecks, queryClient, saveDecksMutateAsync]);

  const deleteFlashcard = useCallback((deckId: string, cardId: string) => {
    void enqueuePersistenceTask('deleteFlashcard', async () => {
      const currentDecks = await getHydratedDecks();
      const updatedDecks = reconcileDeckCatalog(currentDecks.map((deck) => {
        if (deck.id !== deckId) {
          return deck;
        }

        return normalizeDeck({
          ...deck,
          flashcards: deck.flashcards.filter((card) => card.id !== cardId),
        });
      }), 'deck_update').decks;

      queryClient.setQueryData(['decks'], updatedDecks);

      try {
        await saveDecksMutateAsync(updatedDecks);
      } catch (error) {
        queryClient.setQueryData(['decks'], currentDecks);
        logger.error('[FlashQuest] Failed to persist flashcard deletion, rolled back cache', error);
        throw error;
      }
    }).catch((error) => {
      logger.error('[FlashQuest] deleteFlashcard task failed', error);
    });
  }, [enqueuePersistenceTask, getHydratedDecks, queryClient, saveDecksMutateAsync]);

  const deleteDeck = useCallback(async (deckId: string) => {
    return enqueuePersistenceTask('deleteDeck', async () => {
      logger.debug('[FlashQuest] Starting delete for deck:', deckId);
      const currentDecks = await getHydratedDecks();
      if (BUILT_IN_DECK_IDS.has(deckId)) {
        logger.debug('[FlashQuest] Prevented delete of built-in deck:', deckId);
        return currentDecks;
      }

      const currentProgress = await getHydratedProgress();
      const filteredDecks = currentDecks.filter((deck) => deck.id !== deckId);

      if (filteredDecks.length === currentDecks.length) {
        logger.debug('[FlashQuest] Deck not found, aborting delete');
        return currentDecks;
      }

      const reconciledDecks = reconcileDeckCatalog(filteredDecks, 'deck_update').decks;
      const filteredProgress = currentProgress.filter((entry) => entry.deckId !== deckId);
      queryClient.setQueryData(['decks'], reconciledDecks);
      queryClient.setQueryData(['progress'], filteredProgress);

      try {
        await Promise.all([
          saveDecksMutateAsync(reconciledDecks),
          filteredProgress.length !== currentProgress.length ? saveProgressMutateAsync(filteredProgress) : Promise.resolve([]),
        ]);
        logger.debug('[FlashQuest] Persisted deck delete via queued mutation');
      } catch (error) {
        queryClient.setQueryData(['decks'], currentDecks);
        queryClient.setQueryData(['progress'], currentProgress);
        logger.error('[FlashQuest] Failed to persist deck delete, rolled back cache', error);
        throw error;
      }

      return reconciledDecks;
    });
  }, [enqueuePersistenceTask, getHydratedDecks, getHydratedProgress, queryClient, saveDecksMutateAsync, saveProgressMutateAsync]);

  const updateProgress = useCallback((deckId: string) => {
    void enqueuePersistenceTask('updateProgress', async () => {
      const currentProgress = await getHydratedProgress();
      const existingIndex = currentProgress.findIndex((entry) => entry.deckId === deckId);
      let updatedProgress: UserProgress[];

      if (existingIndex >= 0) {
        const existing = currentProgress[existingIndex];
        updatedProgress = [...currentProgress];
        updatedProgress[existingIndex] = {
          ...existing,
          cardsReviewed: existing.cardsReviewed + 1,
          lastStudied: Date.now(),
        };
      } else {
        updatedProgress = [
          ...currentProgress,
          {
            deckId,
            cardsReviewed: 1,
            lastStudied: Date.now(),
            masteredCards: [],
          },
        ];
      }

      queryClient.setQueryData(['progress'], updatedProgress);

      try {
        await saveProgressMutateAsync(updatedProgress);
      } catch (error) {
        queryClient.setQueryData(['progress'], currentProgress);
        logger.error('[FlashQuest] Failed to persist progress update, rolled back cache', error);
        throw error;
      }
    }).catch((error) => {
      logger.error('[FlashQuest] updateProgress task failed', error);
    });
  }, [enqueuePersistenceTask, getHydratedProgress, queryClient, saveProgressMutateAsync]);

  return useMemo(() => ({
    decks: decksQuery.data ?? [],
    progress: progressQuery.data ?? [],
    stats: statsQuery.data ?? DEFAULT_STATS,
    isLoading: decksQuery.isLoading || progressQuery.isLoading || statsQuery.isLoading,
    addDeck,
    updateDeck,
    updateFlashcard,
    deleteFlashcard,
    deleteDeck,
    updateProgress,
    recordSessionResult,
  }), [
    decksQuery.data,
    progressQuery.data,
    statsQuery.data,
    decksQuery.isLoading,
    progressQuery.isLoading,
    statsQuery.isLoading,
    addDeck,
    updateDeck,
    updateFlashcard,
    deleteFlashcard,
    deleteDeck,
    updateProgress,
    recordSessionResult,
  ]);
});

export function useDeckProgress(deckId: string) {
  const { progress } = useFlashQuest();

  return useMemo(
    () => progress.find((entry) => entry.deckId === deckId),
    [progress, deckId],
  );
}
