export const lightTheme = {
  background: '#E0E7FF',
  cardBackground: 'rgba(255, 255, 255, 0.95)',
  card: '#fff',
  text: '#1a1a1a',
  textSecondary: '#666',
  textTertiary: '#999',
  primary: '#667eea',
  primaryDark: '#764ba2',
  gradientStart: '#667eea',
  gradientMid: '#764ba2',
  gradientEnd: '#f093fb',
  success: '#10b981',
  warning: '#f59e0b',
  error: '#ef4444',
  border: '#e0e0e0',
  shadow: '#000',
  modalOverlay: 'rgba(0, 0, 0, 0.6)',
  white: '#fff',
  statsCard: 'rgba(255, 255, 255, 0.95)',
  profileCard: ['#E0E7FF', '#F3E8FF', '#FFF1F2'] as const,
  scoreGradient: ['#10b981', '#059669'] as const,
  deckGradient: ['#8b5cf6', '#7c3aed'] as const,
  arenaGradient: ['#f97316', '#ea580c'] as const,
  arenaSurface: 'rgba(255, 255, 255, 0.95)',
  arenaTableSurface: 'rgba(0, 50, 35, 0.3)',
  arenaOverlay: 'rgba(255, 255, 255, 0.18)',
  questGradient: ['#6366f1', '#4f46e5'] as const,
  deckCardBg: 'rgba(255, 255, 255, 0.95)',
  deckOption: '#e8eaf0',
  profileStatSurface: 'rgba(255, 255, 255, 0.15)',
  profileTabBackground: 'rgba(255, 255, 255, 0.65)',
  profileTabActiveGradient: ['#667eea', '#764ba2'] as const,
  profileTabInactiveText: '#666',
  profileTabActiveText: '#fff',
  profileTabIconInactive: '#666',
  achievementBaseGradient: ['#E0E7FF', '#C7D2FE'] as const,
  achievementCompletedGradient: ['#D1FAE5', '#A7F3D0'] as const,
  sheetHandle: 'rgba(15, 23, 42, 0.12)',
};

export const darkTheme = {
  background: '#0f172a',
  cardBackground: '#1e293b',
  card: '#1e293b',
  text: '#f1f5f9',
  textSecondary: '#cbd5e1',
  textTertiary: '#94a3b8',
  primary: '#8b5cf6',
  primaryDark: '#7c3aed',
  gradientStart: '#1e293b',
  gradientMid: '#334155',
  gradientEnd: '#0f172a',
  success: '#10b981',
  warning: '#f59e0b',
  error: '#ef4444',
  border: '#334155',
  shadow: '#000',
  modalOverlay: 'rgba(0, 0, 0, 0.8)',
  white: '#fff',
  statsCard: '#1e293b',
  profileCard: ['#111827', '#1f2937', '#312e81'] as const,
  scoreGradient: ['#10b981', '#059669'] as const,
  deckGradient: ['#6366f1', '#4f46e5'] as const,
  arenaGradient: ['#f97316', '#ea580c'] as const,
  arenaSurface: '#1e293b',
  arenaTableSurface: 'rgba(0, 30, 20, 0.6)',
  arenaOverlay: 'rgba(255, 255, 255, 0.08)',
  questGradient: ['#8b5cf6', '#7c3aed'] as const,
  deckCardBg: '#1e293b',
  deckOption: '#2d3748',
  profileStatSurface: 'rgba(148, 163, 184, 0.14)',
  profileTabBackground: 'rgba(15, 23, 42, 0.75)',
  profileTabActiveGradient: ['#6366f1', '#7c3aed'] as const,
  profileTabInactiveText: '#94a3b8',
  profileTabActiveText: '#e0e7ff',
  profileTabIconInactive: '#94a3b8',
  achievementBaseGradient: ['#1f2937', '#111827'] as const,
  achievementCompletedGradient: ['#134e4a', '#0f766e'] as const,
  sheetHandle: 'rgba(148, 163, 184, 0.35)',
};

export type Theme = {
  background: string;
  cardBackground: string;
  card: string;
  text: string;
  textSecondary: string;
  textTertiary: string;
  primary: string;
  primaryDark: string;
  gradientStart: string;
  gradientMid: string;
  gradientEnd: string;
  success: string;
  warning: string;
  error: string;
  border: string;
  shadow: string;
  modalOverlay: string;
  white: string;
  statsCard: string;
  profileCard: readonly [string, string, string];
  scoreGradient: readonly [string, string];
  deckGradient: readonly [string, string];
  arenaGradient: readonly [string, string];
  questGradient: readonly [string, string];
  deckCardBg: string;
  deckOption: string;
  profileStatSurface: string;
  profileTabBackground: string;
  profileTabActiveGradient: readonly [string, string];
  profileTabInactiveText: string;
  profileTabActiveText: string;
  profileTabIconInactive: string;
  achievementBaseGradient: readonly [string, string];
  achievementCompletedGradient: readonly [string, string];
  sheetHandle: string;
  arenaSurface: string;
  arenaTableSurface: string;
  arenaOverlay: string;
};
